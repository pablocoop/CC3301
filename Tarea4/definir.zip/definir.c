#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>


#define TAM_MAX 255

typedef struct {
    int izq, der;
    uint16_t tam_llave, tam_valor;
} NodoArch;

int main(int argc, char *argv[]) {
    // Verificar que se reciban los parámetros correctos
    if (argc != 4) {    // Los parámetros son el nombre del archivo, la llave y el valor
        // Error de uso (mal ingreso de parámetros)
        fprintf(stderr, "uso: ./definir <archivo> <llave> <definicion>\n");
        exit(1);
    }

    // Abrir el archivo en modo r+ (leer y escribir)
    char *nom = argv[1];
    FILE *dicc = fopen(nom, "r+");
    if (dicc == NULL) { // Si no se puede abrir el archivo
        perror(nom);
        exit(1);
    }

    
    fseek(dicc, 0, SEEK_SET); // Volver al inicio del archivo después de la verificación

    // Obtener la llave y el valor desde los parámetros de la línea de comandos
    char *llave = argv[2];
    char *valor = argv[3];

    // Obtener el tamaño de la llave y el valor
    uint16_t tam_llave = strlen(llave);
    uint16_t tam_valor = strlen(valor);

    // Variables para la búsqueda
    NodoArch nodo;
    char buffer_llave[TAM_MAX];
    char buffer_valor[TAM_MAX];
    int encontrado = 0;
    long pos = 0;

    // Leer el archivo y buscar la llave usando la estructura de árbol binario
    while (1) { //while(true)
        fseek(dicc, pos, SEEK_SET);
        if (fread(&nodo, sizeof(NodoArch), 1, dicc) != 1) {
            break;  // Para detener el while si no se puede leer un nodo
        }
        // Leer la llave y el valor
        fread(buffer_llave, sizeof(char), nodo.tam_llave, dicc);
        // Guardar la llave en el buffer
        buffer_llave[nodo.tam_llave] = '\0'; // Asegurar terminación de string
        fread(buffer_valor, sizeof(char), nodo.tam_valor, dicc);
        // Guardar el valor en el buffer
        buffer_valor[nodo.tam_valor] = '\0'; // Asegurar terminación de string

        // Comparar la llave actual con la llave buscada
        int cmp = strcmp(buffer_llave, llave);
        if (cmp == 0) { // Si la llave ya existe, terminar 
            // mensaje de error
            fprintf(stderr, "Llave existente: no se puede modificar la llave %s\n", llave);
            fclose(dicc);   // Cerrar el archivo
            exit(1);
        } else if (cmp < 0) { // Si la llave actual es menor que la buscada
            // Buscar en el subárbol derecho
            if (nodo.der == -1) {   // Si no hay subárbol derecho
                // Insertar en el subárbol derecho
                fseek(dicc, 0, SEEK_END);
                int nueva_pos = ftell(dicc);
                fseek(dicc, pos + sizeof(int), SEEK_SET);
                fwrite(&nueva_pos, sizeof(int), 1, dicc);
                fseek(dicc, nueva_pos, SEEK_SET);

                // Escribir el nuevo nodo
                nodo.izq = -1;
                nodo.der = -1;
                nodo.tam_llave = tam_llave;
                nodo.tam_valor = tam_valor;
                fwrite(&nodo, sizeof(NodoArch), 1, dicc);
                fwrite(llave, sizeof(char), tam_llave, dicc);
                fwrite(valor, sizeof(char), tam_valor, dicc);

                encontrado = 1;
                break;
            } else {
                // Seguir buscando en el subárbol derecho
                pos = nodo.der;
            }
        } else {
            // cmp > 0
            if (nodo.izq == -1) {
                // Insertar en el subárbol izquierdo
                fseek(dicc, 0, SEEK_END);
                int nueva_pos = ftell(dicc);
                fseek(dicc, pos, SEEK_SET);
                fwrite(&nueva_pos, sizeof(int), 1, dicc);
                fseek(dicc, nueva_pos, SEEK_SET);

                // Escribir el nuevo nodo
                nodo.izq = -1;
                nodo.der = -1;
                nodo.tam_llave = tam_llave;
                nodo.tam_valor = tam_valor;
                fwrite(&nodo, sizeof(NodoArch), 1, dicc);
                fwrite(llave, sizeof(char), tam_llave, dicc);
                fwrite(valor, sizeof(char), tam_valor, dicc);
                encontrado = 1;
                break;
            } else {
                // Seguir buscando en el subárbol izquierdo
                pos = nodo.izq;
            }
        }
    }

    // Si la llave no existe, agregarla en la posición correcta
    if (!encontrado) {
        fseek(dicc, 0, SEEK_END);
        // Escribir la posición del nuevo nodo
        nodo.izq = -1;
        nodo.der = -1;
        nodo.tam_llave = tam_llave;
        nodo.tam_valor = tam_valor;
        // Escribir el nuevo nodo
        fwrite(&nodo, sizeof(NodoArch), 1, dicc);
        fwrite(llave, sizeof(char), tam_llave, dicc);
        fwrite(valor, sizeof(char), tam_valor, dicc);
    }

    // Cerrar el archivo
    fclose(dicc);
    // En caso de éxito, terminar con código 0
    return 0;
}
